# 📊 Dashboard Interactivo de Inventario - Lalalou

## Descripción
Dashboard web interactivo para visualización y gestión del inventario de Lalalou, temporada Invierno 2026. Proporciona análisis en tiempo real, alertas críticas y herramientas de decisión.

## 🚀 Características Principales

### 📈 Visualización de Datos
- **KPIs en tiempo real**: Stock disponible, ventas semanales, semanas restantes
- **Gráficos interactivos**: Ventas por categoría, proyección de stock
- **Tabla de productos críticos**: Filtros y búsqueda en tiempo real

### ⚡ Funcionalidades Interactivas
- **Filtros dinámicos**: Por estado (crítico/advertencia/bueno), categoría
- **Búsqueda inteligente**: En productos, categorías, tallas, códigos
- **Paginación**: Navegación por lotes de productos
- **Actualización simulada**: Datos que cambian en tiempo real

### 📊 Herramientas de Análisis
- **Detalles de producto**: Información completa al hacer clic
- **Sistema de alertas**: Notificaciones de cambios en stock
- **Proyecciones**: Estimación de agotamiento de inventario
- **Recomendaciones**: Sugerencias basadas en datos

### 📁 Exportación de Datos
- **Exportar a PDF**: Reportes formateados profesionalmente
- **Exportar a Excel**: Datos estructurados en múltiples hojas
- **Impresión optimizada**: Vistas preparadas para impresión

## 🏗️ Estructura del Proyecto

```
inventario_dashboard/
├── index.html              # Página principal
├── css/
│   └── styles.css         # Estilos personalizados
├── js/
│   └── app.js            # Lógica de la aplicación
├── data/
│   └── inventory.json    # Datos del inventario (simulación API)
└── README.md             # Este archivo
```

## 🛠️ Tecnologías Utilizadas

- **HTML5**: Estructura semántica
- **Tailwind CSS**: Framework CSS utility-first
- **Chart.js**: Gráficos interactivos
- **JavaScript ES6+**: Lógica de la aplicación
- **DataTables**: Tablas interactivas (jQuery)
- **SheetJS (xlsx)**: Exportación a Excel
- **PDFMake**: Generación de PDFs
- **Font Awesome**: Iconografía

## 📋 Instalación y Uso

### Opción 1: Servidor Local Simple
```bash
# Navegar al directorio
cd /home/node/.openclaw/workspace/inventario_dashboard

# Usar Python para servir (si está disponible)
python3 -m http.server 8000

# O usar Node.js
npx serve .
```

### Opción 2: Abrir Directamente
Simplemente abrir `index.html` en un navegador moderno.

### Opción 3: Servir con OpenClaw
```bash
# Desde el directorio de OpenClaw
openclaw serve ./inventario_dashboard --port 8080
```

## 🎯 Funcionalidades por Sección

### 1. **Header y Controles**
- Fecha de última actualización
- Botones de exportación (PDF/Excel)
- Título y logo del dashboard

### 2. **Alertas Críticas**
- Banner rojo para situaciones urgentes
- Botón para saltar a productos críticos
- Actualización automática

### 3. **Filtros**
- Botones de estado (Crítico/Advertencia/Bueno/Todos)
- Filtros por categoría (Jeans/Blazers/Pantalones)
- Búsqueda en tiempo real

### 4. **Tarjetas KPI**
- Stock disponible con barra de progreso
- Ventas semanales con tendencia
- Semanas restantes con proyección
- Tallas agotadas con porcentaje

### 5. **Gráficos**
- **Dona**: Distribución de ventas por categoría
- **Línea**: Proyección de agotamiento de stock
- Responsivos y con tooltips

### 6. **Tabla de Productos Críticos**
- 10 columnas de información
- Filtrado y ordenamiento
- Paginación personalizada
- Acciones por producto (ver detalles/ordenar)

### 7. **Tendencias y Análisis**
- Top 5 productos más vendidos
- Problemas detectados
- Recomendaciones priorizadas

## 🔧 Personalización

### Modificar Datos
Editar `data/inventory.json` para:
- Actualizar números del inventario
- Agregar nuevos productos
- Modificar categorías
- Ajustar proyecciones

### Cambiar Estilos
Editar `css/styles.css` para:
- Modificar colores corporativos
- Ajustar tamaños y espaciados
- Agregar animaciones personalizadas

### Extender Funcionalidad
Editar `js/app.js` para:
- Agregar nuevos filtros
- Implementar conexión a API real
- Crear nuevas visualizaciones
- Añadir autenticación

## 📱 Responsive Design
El dashboard está optimizado para:
- **Desktop**: Layout de 4 columnas, tablas completas
- **Tablet**: Layout de 2 columnas, tablas scrollables
- **Mobile**: Layout de 1 columna, cards apiladas

## 🚨 Sistema de Alertas

### Tipos de Alertas
1. **Crítico**: Stock ≤1 semana (rojo, animación)
2. **Advertencia**: Stock 1-3 semanas (naranja)
3. **Bueno**: Stock >3 semanas (verde)

### Notificaciones
- Cambios en tiempo real (simulados)
- Tooltips informativos
- Mensajes de confirmación

## 📊 Exportación

### Formato PDF
- Diseño profesional
- Incluye resumen ejecutivo
- Tabla de productos críticos
- Recomendaciones

### Formato Excel
- 3 hojas organizadas
- Datos estructurados
- Listo para análisis adicional

## 🔄 Simulación en Tiempo Real

La aplicación incluye una simulación que:
- Actualiza stock aleatoriamente cada 30 segundos
- Recalcula semanas restantes
- Cambia estados automáticamente
- Muestra notificaciones

Para desactivar la simulación, comentar la línea en `app.js`:
```javascript
// simulateRealTimeUpdate();
```

## 🧪 Testing

### Pruebas Recomendadas
1. **Filtros**: Probar combinaciones de filtros
2. **Búsqueda**: Buscar por nombre, categoría, talla
3. **Exportación**: Generar PDF y Excel
4. **Responsive**: Redimensionar ventana
5. **Interacciones**: Hacer clic en botones y enlaces

### Consola de Desarrollo
- Presionar F12 para abrir herramientas de desarrollo
- Ver mensajes en la consola JavaScript
- Inspeccionar solicitudes de red (simuladas)

## 📈 Integración con Sistemas Reales

### Conexión a API
Para conectar con un backend real:

1. Reemplazar `inventoryData` en `app.js` por llamadas fetch
2. Implementar WebSocket para actualizaciones en tiempo real
3. Agregar autenticación JWT o similar

### Ejemplo de Conexión API
```javascript
// En app.js, reemplazar:
async function loadInventoryData() {
    const response = await fetch('/api/inventory');
    return await response.json();
}
```

## 🐛 Solución de Problemas

### Problemas Comunes

1. **Los gráficos no se muestran**
   - Verificar que Chart.js esté cargado
   - Revisar la consola por errores JavaScript

2. **Los filtros no funcionan**
   - Verificar que los event listeners estén configurados
   - Revisar la función `filterData()`

3. **Exportación falla**
   - Verificar que las librerías PDFMake y SheetJS estén cargadas
   - Revisar permisos del navegador

4. **Diseño no responsive**
   - Verificar clases de Tailwind CSS
   - Revisar media queries en CSS personalizado

### Debugging
```javascript
// Agregar en app.js para debug
console.log('Datos filtrados:', filteredData);
console.log('Página actual:', currentPage);
```

## 📚 Recursos Adicionales

### Documentación
- [Tailwind CSS](https://tailwindcss.com/docs)
- [Chart.js](https://www.chartjs.org/docs/)
- [DataTables](https://datatables.net/manual/)
- [SheetJS](https://docs.sheetjs.com/)
- [PDFMake](http://pdfmake.org/#/)

### Mejoras Futuras
1. **Autenticación de usuarios**
2. **Roles y permisos**
3. **Histórico de cambios**
4. **Sistema de notificaciones push**
5. **Integración con ERP**
6. **Machine learning para predicciones**

## 👥 Contribución

1. Fork el proyecto
2. Crear rama de feature (`git checkout -b feature/AmazingFeature`)
3. Commit cambios (`git commit -m 'Add AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abrir Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver `LICENSE` para más detalles.

## ✨ Créditos

Desarrollado por **Equipo AV Capital**  
**Tomás Acevedo** - Product Owner  
**Asistente Principal** - Desarrollo y Coordinación

---

**📅 Última actualización:** 13 de Abril 2026  
**🎯 Estado del proyecto:** ✅ Completo y funcional  
**🚀 Próximo hito:** Integración con API real